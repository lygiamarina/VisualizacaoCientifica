Before running make on the terminal, first run:
"make clean" 
and then:
"make"
